"use strict";
(() => {
  // src/lib/domain-guard.ts
  function normalizeHostname(rawInput) {
    const trimmed = rawInput.trim();
    if (!trimmed || trimmed.length > 253 || /\s/.test(trimmed)) {
      return null;
    }
    try {
      const withProtocol = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(trimmed) ? trimmed : `https://${trimmed}`;
      const parsed = new URL(withProtocol);
      const host = parsed.hostname.toLowerCase().replace(/\.+$/, "");
      if (!host || host.length > 253) return null;
      if (!/^[a-z0-9.-]+$|^\[[0-9a-f:]+\]$/i.test(host)) {
        return null;
      }
      return host;
    } catch {
      return null;
    }
  }

  // extension/src/types.ts
  var DEFAULT_SETTINGS = {
    enabled: true,
    apiBaseUrl: "https://sol-shield.xyz",
    network: "mainnet",
    customRpcUrl: "",
    strictMode: false,
    veniceApiKey: "",
    trustedDomains: [],
    blockedDomains: []
  };

  // extension/src/options.ts
  function parseDomainLines(raw) {
    return Array.from(
      new Set(
        raw.split(/\r?\n/).map((line) => normalizeHostname(line)).filter((host) => Boolean(host))
      )
    );
  }
  async function loadOptions() {
    const res = await chrome.runtime.sendMessage({ type: "SOLSHIELD_GET_POPUP_STATE" });
    if (!res?.ok || !res.snapshot) return;
    const s = res.snapshot.settings;
    document.getElementById("api-base-url").value = s.apiBaseUrl;
    document.getElementById("network").value = s.network;
    document.getElementById("custom-rpc").value = s.customRpcUrl;
    document.getElementById("venice-key").value = s.veniceApiKey;
    document.getElementById("strict-mode").checked = s.strictMode;
    document.getElementById("trusted-domains").value = s.trustedDomains.join("\n");
    document.getElementById("blocked-domains").value = s.blockedDomains.join("\n");
  }
  document.addEventListener("DOMContentLoaded", () => {
    void loadOptions();
    const apiInput = document.getElementById("api-base-url");
    const statusEl = document.getElementById("save-status");
    document.getElementById("preset-local")?.addEventListener("click", () => {
      apiInput.value = "http://localhost:3000";
    });
    document.getElementById("preset-prod")?.addEventListener("click", () => {
      apiInput.value = "https://sol-shield.xyz";
    });
    document.getElementById("save-btn")?.addEventListener("click", async () => {
      const next = {
        apiBaseUrl: apiInput.value.trim() || DEFAULT_SETTINGS.apiBaseUrl,
        network: document.getElementById("network").value === "devnet" ? "devnet" : "mainnet",
        customRpcUrl: document.getElementById("custom-rpc").value.trim(),
        veniceApiKey: document.getElementById("venice-key").value.trim(),
        strictMode: document.getElementById("strict-mode").checked,
        trustedDomains: parseDomainLines(
          document.getElementById("trusted-domains").value
        ),
        blockedDomains: parseDomainLines(
          document.getElementById("blocked-domains").value
        )
      };
      const res = await chrome.runtime.sendMessage({
        type: "SOLSHIELD_UPDATE_SETTINGS",
        settings: next
      });
      statusEl.textContent = res?.ok ? "Settings saved cleanly to chrome.storage.local." : "Failed to save settings.";
      setTimeout(() => {
        statusEl.textContent = "";
      }, 3500);
    });
    document.getElementById("reset-btn")?.addEventListener("click", async () => {
      const res = await chrome.runtime.sendMessage({
        type: "SOLSHIELD_UPDATE_SETTINGS",
        settings: { ...DEFAULT_SETTINGS }
      });
      if (res?.ok) {
        await loadOptions();
        statusEl.textContent = "Restored default production configuration.";
        setTimeout(() => {
          statusEl.textContent = "";
        }, 3500);
      }
    });
  });
})();
