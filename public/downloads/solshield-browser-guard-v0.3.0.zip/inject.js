"use strict";
(() => {
  // extension/src/provider-wrapper.ts
  var SOLSHIELD_WRAPPED_SYMBOL = /* @__PURE__ */ Symbol.for("solshield.wrapped.v1");
  var BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  function uint8ArrayToBase64(bytes) {
    if (typeof globalThis.btoa === "function") {
      let binary = "";
      const chunkSize = 32768;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        const sub = bytes.subarray(i, i + chunkSize);
        binary += String.fromCharCode(...sub);
      }
      return globalThis.btoa(binary);
    }
    if (typeof Buffer !== "undefined") {
      return Buffer.from(bytes).toString("base64");
    }
    throw new Error("No base64 encoder available in runtime.");
  }
  function decodeUtf8Preview(bytes) {
    try {
      if (typeof TextDecoder !== "undefined") {
        return new TextDecoder("utf-8", { fatal: false }).decode(bytes).slice(0, 260);
      }
    } catch {
    }
    return "";
  }
  function serializeTransactionLike(tx) {
    if (!tx) return null;
    if (tx instanceof Uint8Array) {
      return uint8ArrayToBase64(tx);
    }
    if (ArrayBuffer.isView(tx)) {
      const view = new Uint8Array(tx.buffer, tx.byteOffset, tx.byteLength);
      return uint8ArrayToBase64(view);
    }
    if (typeof tx === "object") {
      const candidate = tx;
      if (typeof candidate.serialize === "function") {
        const targetForSerialize = (() => {
          const rec = candidate;
          if (Array.isArray(rec.signatures)) {
            try {
              return Object.assign(
                Object.create(Object.getPrototypeOf(candidate)),
                candidate,
                { signatures: [...rec.signatures] }
              );
            } catch {
              return candidate;
            }
          }
          return candidate;
        })();
        try {
          const bytes = targetForSerialize.serialize({
            requireAllSignatures: false,
            verifySignatures: false
          });
          if (bytes instanceof Uint8Array) {
            return uint8ArrayToBase64(bytes);
          }
          if (ArrayBuffer.isView(bytes)) {
            const view = bytes;
            return uint8ArrayToBase64(
              new Uint8Array(view.buffer, view.byteOffset, view.byteLength)
            );
          }
        } catch {
          try {
            const bytes = targetForSerialize.serialize();
            if (bytes instanceof Uint8Array) {
              return uint8ArrayToBase64(bytes);
            }
          } catch {
            return null;
          }
        }
      }
    }
    return null;
  }
  function decodeBase58ToBytes(encoded) {
    if (!encoded || encoded.length < 32) return null;
    const bytes = [0];
    for (let i = 0; i < encoded.length; i++) {
      const ch = encoded[i];
      const val = BASE58_ALPHABET.indexOf(ch);
      if (val < 0) return null;
      let carry = val;
      for (let j = 0; j < bytes.length; j++) {
        carry += bytes[j] * 58;
        bytes[j] = carry & 255;
        carry >>= 8;
      }
      while (carry > 0) {
        bytes.push(carry & 255);
        carry >>= 8;
      }
    }
    for (let i = 0; i < encoded.length && encoded[i] === "1"; i++) {
      bytes.push(0);
    }
    return new Uint8Array(bytes.reverse());
  }
  function extractTxAsBase64(candidate) {
    if (!candidate) return null;
    if (typeof candidate === "string") {
      const trimmed = candidate.trim();
      const b58 = decodeBase58ToBytes(trimmed);
      if (b58 && b58.length > 0) {
        return uint8ArrayToBase64(b58);
      }
      if (/^[A-Za-z0-9+/=]{32,}$/.test(trimmed)) {
        return trimmed;
      }
      return null;
    }
    return serializeTransactionLike(candidate);
  }
  function extractSignInInput(raw) {
    if (!raw || typeof raw !== "object") return void 0;
    const rec = raw;
    const input = {};
    if (typeof rec.domain === "string") input.domain = rec.domain;
    if (typeof rec.statement === "string") input.statement = rec.statement;
    if (typeof rec.uri === "string") input.uri = rec.uri;
    return input.domain || input.statement || input.uri ? input : void 0;
  }
  function buildLegacyInterceptInput(walletName, methodName, args) {
    if (methodName === "signTransaction" || methodName === "signAndSendTransaction") {
      const serialized = serializeTransactionLike(args[0]);
      return {
        walletName,
        walletMethod: methodName,
        base64Transactions: serialized ? [serialized] : []
      };
    }
    if (methodName === "signAllTransactions") {
      const txList = Array.isArray(args[0]) ? args[0] : [];
      const serializedList = txList.map((item) => serializeTransactionLike(item)).filter((item) => typeof item === "string");
      return {
        walletName,
        walletMethod: "signAllTransactions",
        base64Transactions: serializedList
      };
    }
    if (methodName === "signMessage") {
      const rawMsg = args[0];
      const msgBytes = rawMsg instanceof Uint8Array ? rawMsg : ArrayBuffer.isView(rawMsg) ? new Uint8Array(rawMsg.buffer, rawMsg.byteOffset, rawMsg.byteLength) : new Uint8Array(0);
      return {
        walletName,
        walletMethod: "signMessage",
        signMessageBytesBase64: uint8ArrayToBase64(msgBytes),
        signMessagePreviewText: decodeUtf8Preview(msgBytes)
      };
    }
    if (methodName === "signIn") {
      return {
        walletName,
        walletMethod: "signIn",
        signInInput: extractSignInInput(args[0])
      };
    }
    return {
      walletName,
      walletMethod: "connect"
    };
  }
  function buildRpcRequestInterceptInput(walletName, rpcMethod, params) {
    if (rpcMethod === "signTransaction" || rpcMethod === "signAndSendTransaction") {
      const txRaw = params?.transaction ?? params?.message;
      const b64 = extractTxAsBase64(txRaw);
      return {
        walletName,
        walletMethod: rpcMethod,
        base64Transactions: b64 ? [b64] : []
      };
    }
    if (rpcMethod === "signAllTransactions") {
      const rawList = Array.isArray(params?.transactions) ? params.transactions : Array.isArray(params?.message) ? params.message : [];
      const serialized = rawList.map((item) => extractTxAsBase64(item)).filter((item) => typeof item === "string");
      return {
        walletName,
        walletMethod: "signAllTransactions",
        base64Transactions: serialized
      };
    }
    if (rpcMethod === "signMessage") {
      const msgParam = params?.message;
      if (msgParam instanceof Uint8Array) {
        return {
          walletName,
          walletMethod: "signMessage",
          signMessageBytesBase64: uint8ArrayToBase64(msgParam),
          signMessagePreviewText: decodeUtf8Preview(msgParam)
        };
      }
      return {
        walletName,
        walletMethod: "signMessage",
        signMessagePreviewText: typeof msgParam === "string" ? msgParam.slice(0, 260) : void 0
      };
    }
    if (rpcMethod === "signIn") {
      return {
        walletName,
        walletMethod: "signIn",
        signInInput: extractSignInInput(params)
      };
    }
    return {
      walletName,
      walletMethod: "connect"
    };
  }
  function createUserRejectedError(message) {
    const err = new Error(
      message || "SolShield Guard: Request rejected by user."
    );
    err.code = 4001;
    return err;
  }
  function tryMarkWrapped(target) {
    try {
      if (Object.isExtensible(target)) {
        Object.defineProperty(target, SOLSHIELD_WRAPPED_SYMBOL, {
          value: true,
          configurable: false,
          enumerable: false
        });
        return true;
      }
    } catch {
    }
    return false;
  }
  function canReplaceProperty(obj, key) {
    if (Object.isFrozen(obj)) return false;
    const desc = Object.getOwnPropertyDescriptor(obj, key);
    if (!desc) return Object.isExtensible(obj);
    if (desc.configurable) return true;
    if ("writable" in desc && desc.writable) return true;
    return false;
  }
  function assignMethod(obj, key, fn) {
    if (!canReplaceProperty(obj, key)) return false;
    try {
      const desc = Object.getOwnPropertyDescriptor(obj, key);
      if (!desc || desc.configurable) {
        Object.defineProperty(obj, key, {
          value: fn,
          writable: true,
          configurable: true,
          enumerable: desc ? desc.enumerable : true
        });
        return true;
      }
      obj[key] = fn;
      return obj[key] === fn;
    } catch {
      return false;
    }
  }
  function wrapLegacyProvider(provider, walletName, hooks) {
    if (!provider || typeof provider !== "object" && typeof provider !== "function") {
      return { status: "NOT_PRESENT", wrappedMethods: [], frozenMethods: [] };
    }
    const target = provider;
    if (target[SOLSHIELD_WRAPPED_SYMBOL]) {
      return { status: "ALREADY_WRAPPED", wrappedMethods: [], frozenMethods: [] };
    }
    const wrappedMethods = [];
    const frozenMethods = [];
    const signingMethods = [
      "signTransaction",
      "signAndSendTransaction",
      "signAllTransactions",
      "signMessage",
      "signIn",
      "connect"
    ];
    for (const methodName of signingMethods) {
      const orig = target[methodName];
      if (typeof orig !== "function") continue;
      const wrapped = async function(...args) {
        const invokeCtx = this && this !== globalThis ? this : target;
        const verdictInput = buildLegacyInterceptInput(walletName, methodName, args);
        const decision = await hooks.interceptRequest(verdictInput);
        if (!decision.allow) {
          throw createUserRejectedError(decision.reason);
        }
        return orig.apply(invokeCtx, args);
      };
      if (assignMethod(target, methodName, wrapped)) {
        wrappedMethods.push(methodName);
      } else {
        frozenMethods.push(methodName);
      }
    }
    const origRequest = target.request;
    if (typeof origRequest === "function") {
      const wrappedRequest = async function(payload) {
        const invokeCtx = this && this !== globalThis ? this : target;
        const rpcMethod = payload?.method;
        if (rpcMethod === "connect" || rpcMethod === "signTransaction" || rpcMethod === "signAndSendTransaction" || rpcMethod === "signAllTransactions" || rpcMethod === "signMessage" || rpcMethod === "signIn") {
          const decision = await hooks.interceptRequest(
            buildRpcRequestInterceptInput(walletName, rpcMethod, payload?.params)
          );
          if (!decision.allow) {
            throw createUserRejectedError(decision.reason);
          }
        }
        return origRequest.call(
          invokeCtx,
          payload
        );
      };
      if (assignMethod(target, "request", wrappedRequest)) {
        wrappedMethods.push("request");
      } else {
        frozenMethods.push("request");
      }
    }
    if (frozenMethods.length > 0 && wrappedMethods.length === 0) {
      return { status: "LIMITED_FROZEN", wrappedMethods, frozenMethods };
    }
    if (wrappedMethods.length > 0) {
      tryMarkWrapped(target);
    }
    return {
      status: frozenMethods.length > 0 ? "LIMITED_FROZEN" : "WRAPPED",
      wrappedMethods,
      frozenMethods
    };
  }
  var INTERCEPTED_LEGACY_METHOD_SET = /* @__PURE__ */ new Set([
    "signTransaction",
    "signAndSendTransaction",
    "signAllTransactions",
    "signMessage",
    "signIn",
    "connect"
  ]);
  function createFrozenProviderProxy(provider, walletName, hooks) {
    const cachedWrappers = /* @__PURE__ */ new Map();
    const proxyShell = {};
    return new Proxy(proxyShell, {
      get(_target, prop) {
        if (prop === SOLSHIELD_WRAPPED_SYMBOL) {
          return true;
        }
        if (cachedWrappers.has(prop)) {
          return cachedWrappers.get(prop);
        }
        const rawVal = Reflect.get(provider, prop, provider);
        if (typeof prop === "string" && INTERCEPTED_LEGACY_METHOD_SET.has(prop) && typeof rawVal === "function") {
          const methodName = prop;
          const wrapped = async function(...args) {
            const decision = await hooks.interceptRequest(
              buildLegacyInterceptInput(walletName, methodName, args)
            );
            if (!decision.allow) {
              throw createUserRejectedError(decision.reason);
            }
            return rawVal.apply(
              provider,
              args
            );
          };
          cachedWrappers.set(prop, wrapped);
          return wrapped;
        }
        if (prop === "request" && typeof rawVal === "function") {
          const wrappedRequest = async function(payload) {
            const rpcMethod = payload?.method;
            if (rpcMethod && INTERCEPTED_LEGACY_METHOD_SET.has(rpcMethod)) {
              const decision = await hooks.interceptRequest(
                buildRpcRequestInterceptInput(
                  walletName,
                  rpcMethod,
                  payload?.params
                )
              );
              if (!decision.allow) {
                throw createUserRejectedError(decision.reason);
              }
            }
            return rawVal.call(
              provider,
              payload
            );
          };
          cachedWrappers.set(prop, wrappedRequest);
          return wrappedRequest;
        }
        if (typeof rawVal === "function") {
          const bound = rawVal.bind(provider);
          cachedWrappers.set(prop, bound);
          return bound;
        }
        return rawVal;
      },
      set(_target, prop, value) {
        return Reflect.set(provider, prop, value, provider);
      },
      has(_target, prop) {
        return Reflect.has(provider, prop);
      },
      ownKeys() {
        return Reflect.ownKeys(provider);
      },
      getOwnPropertyDescriptor(_target, prop) {
        const desc = Reflect.getOwnPropertyDescriptor(provider, prop);
        return desc ? { ...desc, configurable: true } : void 0;
      },
      getPrototypeOf() {
        return Reflect.getPrototypeOf(provider);
      }
    });
  }
  function wrapWalletStandardWallet(wallet, hooks) {
    if (!wallet || typeof wallet !== "object") {
      return { status: "NOT_PRESENT", wrappedMethods: [], frozenMethods: [] };
    }
    const walletObj = wallet;
    if (walletObj[SOLSHIELD_WRAPPED_SYMBOL]) {
      return { status: "ALREADY_WRAPPED", wrappedMethods: [], frozenMethods: [] };
    }
    const features = walletObj.features;
    if (!features || typeof features !== "object") {
      return { status: "NOT_PRESENT", wrappedMethods: [], frozenMethods: [] };
    }
    const walletName = walletObj.name || "WalletStandard";
    const wrappedMethods = [];
    const frozenMethods = [];
    const featureMap = [
      {
        featureKey: "solana:signTransaction",
        fnKey: "signTransaction",
        kind: "signTransaction"
      },
      {
        featureKey: "solana:signAndSendTransaction",
        fnKey: "signAndSendTransaction",
        kind: "signAndSendTransaction"
      },
      {
        featureKey: "solana:signAllTransactions",
        fnKey: "signAllTransactions",
        kind: "signAllTransactions"
      },
      {
        featureKey: "solana:signMessage",
        fnKey: "signMessage",
        kind: "signMessage"
      },
      {
        featureKey: "solana:signIn",
        fnKey: "signIn",
        kind: "signIn"
      },
      {
        featureKey: "standard:connect",
        fnKey: "connect",
        kind: "connect"
      }
    ];
    for (const item of featureMap) {
      const featureObj = features[item.featureKey];
      if (!featureObj || typeof featureObj !== "object") continue;
      const origFn = featureObj[item.fnKey];
      if (typeof origFn !== "function") continue;
      const wrappedFn = async function(...inputs) {
        const invokeCtx = this && this !== globalThis ? this : featureObj;
        let requestPayload;
        if (item.kind === "signTransaction" || item.kind === "signAndSendTransaction" || item.kind === "signAllTransactions") {
          const serializedTxs = inputs.map(
            (inp) => inp && typeof inp === "object" ? serializeTransactionLike(inp.transaction) : null
          ).filter((b) => typeof b === "string");
          const methodToReport = item.kind === "signTransaction" && serializedTxs.length > 1 ? "signAllTransactions" : item.kind;
          requestPayload = {
            walletName,
            walletMethod: methodToReport,
            base64Transactions: serializedTxs
          };
        } else if (item.kind === "signMessage") {
          const firstMsg = inputs[0]?.message;
          const msgBytes = firstMsg instanceof Uint8Array ? firstMsg : new Uint8Array(0);
          requestPayload = {
            walletName,
            walletMethod: "signMessage",
            signMessageBytesBase64: uint8ArrayToBase64(msgBytes),
            signMessagePreviewText: decodeUtf8Preview(msgBytes)
          };
        } else if (item.kind === "signIn") {
          requestPayload = {
            walletName,
            walletMethod: "signIn",
            signInInput: extractSignInInput(inputs[0])
          };
        } else {
          requestPayload = {
            walletName,
            walletMethod: "connect"
          };
        }
        const decision = await hooks.interceptRequest(requestPayload);
        if (!decision.allow) {
          throw createUserRejectedError(decision.reason);
        }
        return origFn.apply(
          invokeCtx,
          inputs
        );
      };
      if (assignMethod(featureObj, item.fnKey, wrappedFn)) {
        wrappedMethods.push(item.featureKey);
      } else {
        frozenMethods.push(item.featureKey);
      }
    }
    if (wrappedMethods.length > 0 && frozenMethods.length === 0) {
      tryMarkWrapped(walletObj);
    }
    if (frozenMethods.length > 0) {
      return { status: "LIMITED_FROZEN", wrappedMethods, frozenMethods };
    }
    if (wrappedMethods.length === 0) {
      return { status: "NOT_PRESENT", wrappedMethods, frozenMethods };
    }
    return { status: "WRAPPED", wrappedMethods, frozenMethods };
  }

  // extension/src/inject.ts
  (() => {
    const WIN = window;
    if (WIN.__SOLSHIELD_INJECT_ACTIVE__) return;
    WIN.__SOLSHIELD_INJECT_ACTIVE__ = true;
    const nativeDefineProperty = Object.defineProperty.bind(Object);
    const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor.bind(Object);
    const nativePostMessage = window.postMessage.bind(window);
    const nativeAddEventListener = window.addEventListener.bind(window);
    const nativeDispatchEvent = window.dispatchEvent.bind(window);
    let bridgePort = null;
    const queuedMessages = [];
    const pendingDecisions = /* @__PURE__ */ new Map();
    let requestSeq = 0;
    const trackedStatus = {
      legacyProvidersWrapped: [],
      walletStandardWrapped: [],
      frozenProviders: [],
      updatedAt: Date.now()
    };
    function postToBridge(msg) {
      if (bridgePort) {
        bridgePort.postMessage(msg);
      } else {
        queuedMessages.push(msg);
      }
    }
    function flushQueuedToBridge() {
      if (!bridgePort || queuedMessages.length === 0) return;
      while (queuedMessages.length > 0) {
        const next = queuedMessages.shift();
        bridgePort.postMessage(next);
      }
    }
    function emitStatus() {
      trackedStatus.updatedAt = Date.now();
      postToBridge({
        type: "SOLSHIELD_PROVIDER_STATUS",
        status: {
          legacyProvidersWrapped: [...trackedStatus.legacyProvidersWrapped],
          walletStandardWrapped: [...trackedStatus.walletStandardWrapped],
          frozenProviders: [...trackedStatus.frozenProviders],
          updatedAt: trackedStatus.updatedAt
        }
      });
    }
    function addUnique(arr, label) {
      if (!arr.includes(label)) {
        arr.push(label);
      }
    }
    function interceptRequest(input) {
      const requestId = `solsh-${Date.now()}-${++requestSeq}`;
      return new Promise((resolve) => {
        const timer = setTimeout(() => {
          if (pendingDecisions.has(requestId)) {
            pendingDecisions.delete(requestId);
            resolve({
              allow: false,
              reason: "SolShield Guard verification timed out waiting for user/extension response."
            });
          }
        }, 12e4);
        pendingDecisions.set(requestId, {
          resolve: (res) => {
            clearTimeout(timer);
            resolve(res);
          }
        });
        postToBridge({
          type: "SOLSHIELD_INTERCEPT_REQUEST",
          payload: {
            requestId,
            walletName: input.walletName,
            walletMethod: input.walletMethod,
            originUrl: window.location.href,
            hostname: window.location.hostname,
            base64Transactions: input.base64Transactions,
            signMessageBytesBase64: input.signMessageBytesBase64,
            signMessagePreviewText: input.signMessagePreviewText,
            signInInput: input.signInInput
          }
        });
      });
    }
    function attachBridgePort(port) {
      bridgePort = port;
      port.onmessage = (event) => {
        const data = event.data;
        if (!data || typeof data !== "object") return;
        if (data.type === "SOLSHIELD_INTERCEPT_DECISION") {
          const entry = pendingDecisions.get(data.requestId);
          if (entry) {
            pendingDecisions.delete(data.requestId);
            entry.resolve({
              allow: Boolean(data.allow),
              reason: data.errorMessage || data.verdict?.headline
            });
          }
        }
      };
      port.postMessage({ type: "SOLSHIELD_PORT_ACK" });
      flushQueuedToBridge();
      emitStatus();
    }
    nativeAddEventListener("message", (event) => {
      if (event.source !== window) return;
      if (event.data && event.data.source === "SOLSHIELD_PORT_INIT" && event.ports?.[0] && !bridgePort) {
        attachBridgePort(event.ports[0]);
      }
    });
    nativePostMessage({ source: "SOLSHIELD_MAIN_READY" }, "*");
    function tryWrapSlotProvider(holder, key, label) {
      const obj = holder[key];
      if (!obj) return false;
      const res = wrapLegacyProvider(obj, label, { interceptRequest });
      if (res.status === "WRAPPED") {
        addUnique(trackedStatus.legacyProvidersWrapped, label);
        return true;
      }
      if (res.status === "LIMITED_FROZEN") {
        const desc = nativeGetOwnPropertyDescriptor(holder, key);
        if (!Object.isFrozen(holder) && (!desc || desc.configurable || desc.writable)) {
          try {
            const proxied = createFrozenProviderProxy(obj, label, {
              interceptRequest
            });
            if (!desc || desc.configurable) {
              nativeDefineProperty(holder, key, {
                value: proxied,
                writable: true,
                configurable: true,
                enumerable: desc ? desc.enumerable : true
              });
            } else {
              holder[key] = proxied;
            }
            addUnique(trackedStatus.legacyProvidersWrapped, `${label} (Proxy)`);
            return true;
          } catch {
          }
        }
        addUnique(trackedStatus.frozenProviders, `${label} (Frozen)`);
        return true;
      }
      return false;
    }
    function inspectAndWrapLegacyProviders() {
      let updated = false;
      const phantomObj = WIN.phantom;
      if (phantomObj && typeof phantomObj === "object") {
        if (tryWrapSlotProvider(phantomObj, "solana", "Phantom")) {
          updated = true;
        }
      }
      for (const [key, label] of [
        ["solana", "Solana"],
        ["solflare", "Solflare"],
        ["backpack", "Backpack"],
        ["glow", "Glow"]
      ]) {
        if (tryWrapSlotProvider(WIN, key, label)) {
          updated = true;
        }
      }
      if (updated) emitStatus();
    }
    function installConfigurableTrap(propName, label) {
      const existingDesc = nativeGetOwnPropertyDescriptor(window, propName);
      if (existingDesc && !existingDesc.configurable) {
        inspectAndWrapLegacyProviders();
        return;
      }
      let internalVal = WIN[propName];
      if (internalVal) {
        inspectAndWrapLegacyProviders();
      }
      try {
        nativeDefineProperty(window, propName, {
          configurable: true,
          enumerable: true,
          get() {
            return internalVal;
          },
          set(nextVal) {
            internalVal = nextVal;
            if (nextVal) {
              if (propName === "phantom") {
                inspectAndWrapLegacyProviders();
              } else {
                const res = wrapLegacyProvider(nextVal, label, {
                  interceptRequest
                });
                if (res.status === "WRAPPED") {
                  addUnique(trackedStatus.legacyProvidersWrapped, label);
                  emitStatus();
                } else if (res.status === "LIMITED_FROZEN") {
                  internalVal = createFrozenProviderProxy(
                    nextVal,
                    label,
                    { interceptRequest }
                  );
                  addUnique(trackedStatus.legacyProvidersWrapped, `${label} (Proxy)`);
                  emitStatus();
                }
              }
            }
          }
        });
      } catch {
      }
    }
    function wrapStandardWalletEntry(wallet) {
      const res = wrapWalletStandardWallet(wallet, { interceptRequest });
      const walletName = wallet && typeof wallet === "object" && "name" in wallet ? String(wallet.name || "WalletStandard") : "WalletStandard";
      if (res.status === "WRAPPED") {
        addUnique(trackedStatus.walletStandardWrapped, walletName);
        emitStatus();
      } else if (res.status === "LIMITED_FROZEN") {
        addUnique(
          trackedStatus.frozenProviders,
          `${walletName} (WalletStandard Frozen)`
        );
        emitStatus();
      }
      return wallet;
    }
    const wrappedRegisterApis = /* @__PURE__ */ new WeakSet();
    function wrapRegisterApi(api) {
      if (!api || typeof api.register !== "function" || wrappedRegisterApis.has(api)) {
        return api;
      }
      const origRegister = api.register;
      const desc = nativeGetOwnPropertyDescriptor(api, "register");
      if (!desc || desc.configurable || desc.writable) {
        try {
          wrappedRegisterApis.add(api);
          const patchedRegister = function(...wallets) {
            const safeWallets = wallets.map((w) => wrapStandardWalletEntry(w));
            return origRegister.apply(this || api, safeWallets);
          };
          if (!desc || desc.configurable) {
            nativeDefineProperty(api, "register", {
              value: patchedRegister,
              writable: true,
              configurable: true,
              enumerable: true
            });
          } else {
            api.register = patchedRegister;
          }
        } catch {
        }
      }
      return api;
    }
    const wrappedCallbacks = /* @__PURE__ */ new WeakSet();
    function patchWalletStandardEvent(event) {
      const customEvent = event;
      if (event.type === "wallet-standard:app-ready" && customEvent.detail) {
        if (typeof customEvent.detail === "object") {
          wrapRegisterApi(
            customEvent.detail
          );
        }
      } else if (event.type === "wallet-standard:register-wallet" && typeof customEvent.detail === "function" && !wrappedCallbacks.has(customEvent.detail)) {
        const origWalletRegisterCb = customEvent.detail;
        const interceptedCb = function(api) {
          wrapRegisterApi(api);
          return origWalletRegisterCb(api);
        };
        wrappedCallbacks.add(interceptedCb);
        const detailDesc = nativeGetOwnPropertyDescriptor(customEvent, "detail");
        if (!detailDesc || detailDesc.configurable) {
          try {
            nativeDefineProperty(customEvent, "detail", {
              value: interceptedCb,
              configurable: true
            });
          } catch {
          }
        }
      }
      return event;
    }
    try {
      window.dispatchEvent = function(event) {
        patchWalletStandardEvent(event);
        return nativeDispatchEvent(event);
      };
    } catch {
    }
    try {
      const origAddListener = nativeAddEventListener;
      window.addEventListener = function(type, listener, options) {
        if (!listener) return;
        if (type === "wallet-standard:register-wallet" || type === "wallet-standard:app-ready") {
          const wrappedListener = (ev) => {
            patchWalletStandardEvent(ev);
            if (typeof listener === "function") {
              listener.call(window, ev);
            } else {
              listener.handleEvent(ev);
            }
          };
          return origAddListener(type, wrappedListener, options);
        }
        return origAddListener(type, listener, options);
      };
    } catch {
    }
    installConfigurableTrap("solana", "Solana");
    installConfigurableTrap("phantom", "Phantom");
    installConfigurableTrap("solflare", "Solflare");
    installConfigurableTrap("backpack", "Backpack");
    installConfigurableTrap("glow", "Glow");
    inspectAndWrapLegacyProviders();
    let polls = 0;
    const pollTimer = setInterval(() => {
      polls++;
      inspectAndWrapLegacyProviders();
      if (polls >= 40) {
        clearInterval(pollTimer);
      }
    }, 150);
    nativeAddEventListener("DOMContentLoaded", inspectAndWrapLegacyProviders);
    nativeAddEventListener("load", inspectAndWrapLegacyProviders);
  })();
})();
