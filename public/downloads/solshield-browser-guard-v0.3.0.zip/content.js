"use strict";
(() => {
  // extension/public/icons/icon48.png
  var icon48_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAA6ASURBVGhD1Vp3dJR1FoWEJDPzTUumpJFOeiWVdEKAFJIQAimE0ATphKZgB8viCtIFwQKKgIKwlEVREJHeBQQsoFjW5dhAQCxn291z35dBCUkMru45/PE7mfnmm2/efe++++7vd9JGq1XOabXKxVt0nWuj1SpXdTo9bsXF2AngYuMPbpXF2P9wABqNDu3aucLZ2QXt2rnAzU17wz2/df1hAFxc3NCmTRtZfO3r64egoBD4BwRBUQzXPnN11TCIG77f2vW7A2CmGZjFYkOfymosevIpbNz0Kg4dOY53Tr2PI0dPYMPGV/D4rLnoWV4hYFghrt8C5HcDQFowcB+f9pgy5V6cOPkuLnz7Hb746iI++ew8jr/zLo4eewf7DxzBocPHBMzZc5/i+eWrEBAQJMHr9cabBnGTAPhwx7r2ADg5tYOrqxtqavpJoN9e/h4fnfsbjh0/hQMHj2L33oPYt/8w3tyxGzve2oPtO3Zhz76DeGvXXpz58BMsXvIsAoOC4ecXcNMgbg6AYoZOZ4BOZ5T3LDv5zazPmj0fV3/4B85/eQEnT7+vBn3gME6d/gDnPvkcZz/6FG8fP4l9B45I8Hv2HcLO3fsFDD+7/4EHoSh6oR5pdcNvN7NaCaAh64o79HovKHobNBqN8D2hYxKWPfcCLl/9CR9/+nehxhtv7sT2Hbslux+c/Rivb9uBBQsXY/6CRZg1ex5mzpqLhYuewhMLF+OlNeuwbftOnHr3DOrqBsJqtcPT07vVStUKAAoUxV1dek8YjEHQaExo27YtYmPjsWLlS7hw6Sq+/Ppb7NpzQILasXMvvr5wGS+uXovy8grExiXAzz8Q/v6BCAwMRseOSYiNTUB5eW9MnnIP5sxdgLXrNmLb9reQndNZaMQqtIZKvwKAWTdBb/CF3uAPoykMGo1eOF9Y2ANbXntD+M5mZcazs3Mxtn48Ll66imnTHoGPj68EQ9pxBnCRbh06hMHb2xdpaemy7r1vKmbPmS9/hw0fiYDAYAFLAL8GogUADN7cELwfjKZw6HRWUZrBt92OYydO4d8ALl35Ea9vfVMCiYyKwdFjJ7Fw0RJkZeeKulg8bBJEeHikzAECIghWom9tHcaMHS/B/3XzawgJCUWXLt2Qnd0ZaZ0yEBkZLT12Y2y/CkDNvKJYoOi9YDRFQ1E84eTkhILCYpz/4htcufoTVq5ag8qqGqEIA1z2/Ars3ncQ/fsPQu/eVbDZPGEwmJCRkS1K89zylRg0aAgCA0MQFBSMOyffjT9NfwyPzZgl1eR96emZ6FNZg8KiEnTtWgC73avFfmgagKiNAkVvh8k9CQZjBzg5OSOkQyj2HzyCy9/9gCFDh8OprbM0cnBwB3n/+fmvMPGOyRg9Zhw6d84XWSTfx0+4A9MfnYGly5ZLdXqUlEm1CCAnpzMiIqJR268/6usnIDEpBePHT0K/uoHo1r0QUVExMq0bB94CADathwRvNEXC7JEu1HFxccHAQUPwr/8ADz08XSSUjUbVYDNTHtmIPct7o3tBkQTPygwbPgpDbx8hvGdFfNv7C7iKikqZxHzPZ0THxGHqtIdRP26iVJBJqO03ABW9q2A0muX3GgffAgAL9Ib2MHukweSeCmdnZySnpGHrGztE7shVs9kdZrOHNCMD/P7Hf6J+/CQBQy0nd5OSUlBb2x+5uV2Qk5OH3Nw89KqoFBtRVd1XwPL93ffcL3+ra2ox/4kn5bOc3DykZ2ShuqafgHdxYcI8oNNdD6RJABxUBlMYPGxlMJjioNNpkZ6ehd17DojsMZMMnoGGhUVg/YbN2PLaNsTHd5QfGz5iNJY9t0KG1PtnzuHw0RNY95dN0gdPPbNMOM9eqqzqizUvr8eH5z6T5942ZJhQsa7/IOR16SYNzvv8/Pzh5qbGxd5Uh2mTABqCNwTA5J4Ci70PNBoLfHy8kZLSSR5IJWHJPTys8gBmlgOMmbZabSjuUSa9cOnKD9e8EJt+994DWL9xswB58aW1WL1mHV7ZshWn3zuDt4+fEvkcMnQYinuUSgOz4nl5+ejVq480vEZrgl7vI+xopgIO5fEQzXe3dofF3gsajQF2u6c0k5eXjwTOxQqQRvPmL8SGTa/AarPD3z9I7lm67AWxB/Q/EvT6TXhm6fNY8vRSMW+OawTD4Tf90ZkSaElpudAqOycP8fGJ0ks9epQhKysHLi4UFa+WAPCCQWwCp63Vsy8snlVQ9GbYbDZV0y02CZ5aTvNGhSFFqCB6vUEalw3n7m5BVFSs9ApX124FokQTJt6JaQ8+Is3K6bti5Wosf2GV8J2VpO5TShMSEpGZmYPi4lKR3I4dk6HRaFVxUdTKNw9AscFkToTdZxQs9p7QatxgsVgR0iEMnfPycd/900SbjUaTNN/OXfug1erg7mGFu7taHYKIiYmDl7cv2rRxEspxstb0rcPY+gmiTFPuuhfzFizCqhfXYPacBQLsycVPy+ccYr37VEkFEhKS5Jl8hpubRixNMz1A/huEZ2aPbNi8B0OjC4PdbkH/AYPRs2eFlJ18Z1bpHCl5zJ7BYJQdFxfBMVgOspGjxwqtOMyoSmx+WpBRo+slYDb0q1u24cCho/jm4hW8vHaDSHSfPtWYOGkykpJTpRpMSERElOpSRYloT1SLcR0ARayDH9wt+TCak6HVukggVJW8Ll0xctRYkUzey6Bsdi8ZZPwB2gMGTh/DqRwXlyC0GTd+ktCA95tMqvRyeD0+a544UXqo9z74SHZu5DsD5erevUiekZycJomhupGibhqj0NwBolETm2EwhsLskQVXNytCQoJRXV2LouJS8Tad0jNlajLrnp4+EhD5zqCYDUeAVKro6FhUVtZgxszZKCgolvtMJlV6aQ3I8T8/NksqUVhYLBSNjIwRqlitnuJUOcy6dSuUHmjvF4AA/0BxwqS5KqeNALACtA0cXm5uRkRHxwgfmQWqEKclHePFS9+LFWD2VTXykAyzuVkNNjy526uij3B90OCh0vD8jIsgflkRguNm38fHT/ju6eUjloLgVq5aLZUhOCblZwCq3WkEwKQCMCdCqzXIkGL2BgwYjJjYeNn2caPORnPsYR1bQPKTtoABhUdECXfLevYS+0EA5L7N5iXBh4ZGSNAMlpJJteH0LS3rhbKeFSgqLhFTR5A1ffthxMjRsn8gpZjYlitgChcDx8lHLg8dOhyZWTnw9m4vgRGI3dNb+EiVYRbVLSDnhZfspsLDo5Ca2klcJU3Z4NuGis53TEwWdaLdcPgo2oWSkp7yG3Gc5KHhkn32XmZmtiSxS3435OV1FWoKAPZAUxVQNy9+MBhD4NzOTcY4J2tGZrZMRk5KTkw2FT0KDRnllLRgJZhd0od9wq0mM0kQ7IWq6lrhM40cQbRv7y+NSRCsGlWKCeAzGGhGRhamTnsEY8aOE4sSF9dRNkgajVkS3YQKOQaZHQZjMNq108gX6+snih4zcDYWpXPEyDHiYyh1bGjKI90iA6C15mLjsVFLy8rl3n51A6QnaNpYCVbP19dfqsmsk2rsrwemPiRg+T2aQFKKSSFggtVqSZ0mB5nqgzjpDIZA6HQWGWLM/JS77pGgyVEari5dukpwbHBShKOeykIZZbOzAtRw8p4eqaqqr1hk7sBYDVJEZLjBFLLhuY/mjDn93lmxHJzu3LXR7YaFRyIlJU0o7eqq0rUJAA4zpxcrbTRFQFG84ezUViTTy8tXVIjlZfPR+g4aPASpqenCYWaJzcl5wQxzatNV3j5spFSPfzlD2JBVVbUSnF4xSjPzd2kheA8Dr+hdKWDr+g8Ue0Gg7C0qmUvLALh0Mo2N5hh1M6N4Q1EUREXHIiW1U8Phk0FOD8aMGYdOnTIl26wUg2IQHHjUcFpkHqU8+PB0sSAzZs7B3HlPyLSlvNJasLLcVt597wMoKCiSipCCfFZaWob0DEWBw02twPW7syYA6BscqQ9M5gSx1bQNtA+sQHJyKixWuzQis1ZY1AP5+d3FsCUlpYpmc6tIAJTbO+68C+MnTJLTCgb+7LLlMoE3v7pVbATdKb0Qv0OKcuaw50g1eiaaPk7lxMQUGI3uN+zMmgTAKjhsBaeyTucNk8l07UyHTccNTmhoODIyc6QBS0vLZVLTVRYVlch7qhev0RpTxwmUM4GnEIuXPCOCQMCUUgZICrLS7BFWOrczm7iXqBfnBJWulQDUXlD0VjmR4P7Azc1VlIOzgJzkUOE0ZpNRVouLS0Sv87t2l017YmKyNF50dJxQj5RjxXjSwGMTfh4cHCr0YJNSzXiN21BWm96K3w0MClF7qnN+kyfYzQNo2LqxodXTOL26sYmOlcbysNjE8zNTHErkKLNJnlIC2dz0T/xhbg8ZIClIZUpNS0dQcAfJOqWSA4xViImJF0XioGPFqHKcRaQVN0pNHa80A8BRBZ0cJ+oNATL96McdzWW1eQqVqEocPlzxCYlShcysXAmG2s33nMJZWbnS8KwC7yNgAmHgpCWpRkAyxRtO7Pgd/hapqihNn1q3AMCxuEfwlhM6rZaO0yzHJVQKDhaOehoxyhyvkbe0y7zucKs0YqwagyHF5JQiN0+SoRo/9kj8Nf4L5bJzpXfUzdNNHas0Xj+fBnDnxSzIcAmLkKZi0KQRK0A3yaA4A8hjxx6a94SEhIl1IP9pM/g6ICBYHCb5zn4gUPV6kAxFSiqr3lTmbwKAAwQ31TxWVyQoNq7jnJOBMkuqPbZIMKwSP+M1GkE2I21yaJiqNAyS32OgPr5+CAuLFM/PRDBg6n1zWf8NABzrugkoy9Tg5x3XCYTUYlXodfgZAyUY0ozH7I5pzgDV02u97O5oL5iAljLeeN0kgBuXgLhmqdXXjn2CY7ND2aVqqe8tAkrNrnLtgMyxr7iZ4Bt+/38D0PCQ617/cjnOULkcg6gxNRzBN35ua9bvAqC1q7kgm7vemvV/BfBHLAeAW/6fPW7pf7f5L+C4eN1/KaUaAAAAAElFTkSuQmCC";

  // extension/src/content.ts
  (() => {
    const WIN = window;
    if (WIN.__SOLSHIELD_CONTENT_ACTIVE__) return;
    WIN.__SOLSHIELD_CONTENT_ACTIVE__ = true;
    let activePort = null;
    let handshakeAcked = false;
    let overlayQueue = Promise.resolve();
    function enqueueOverlay(task) {
      const run = overlayQueue.then(task, task);
      overlayQueue = run.then(
        () => void 0,
        () => void 0
      );
      return run;
    }
    function setupMessageChannel() {
      if (handshakeAcked) return;
      const channel = new MessageChannel();
      const port1 = channel.port1;
      port1.onmessage = (event) => {
        void handleInjectedMessage(event.data, port1);
      };
      window.postMessage({ source: "SOLSHIELD_PORT_INIT" }, "*", [channel.port2]);
    }
    window.addEventListener("message", (event) => {
      if (event.source !== window) return;
      if (event.data?.source === "SOLSHIELD_MAIN_READY" && !handshakeAcked) {
        setupMessageChannel();
      }
    });
    setupMessageChannel();
    async function handleInjectedMessage(data, sourcePort) {
      if (!data || typeof data !== "object") return;
      const msg = data;
      if (msg.type === "SOLSHIELD_PORT_ACK") {
        handshakeAcked = true;
        activePort = sourcePort;
        return;
      }
      if (msg.type === "SOLSHIELD_PROVIDER_STATUS") {
        const status = msg.status;
        try {
          await chrome.runtime.sendMessage({
            type: "SOLSHIELD_PROVIDER_STATUS",
            status
          });
        } catch {
        }
        return;
      }
      if (msg.type === "SOLSHIELD_INTERCEPT_REQUEST") {
        const payload = msg.payload;
        const decision = await processInterceptRequest(payload);
        const replyPort = sourcePort || activePort;
        replyPort?.postMessage({
          type: "SOLSHIELD_INTERCEPT_DECISION",
          ...decision
        });
      }
    }
    async function processInterceptRequest(payload) {
      try {
        const auditResponse = await chrome.runtime.sendMessage({
          type: "SOLSHIELD_RUN_AUDIT",
          payload
        });
        if (auditResponse?.bypass) {
          return {
            requestId: payload.requestId,
            allow: true,
            userAction: "APPROVED",
            verdict: auditResponse.verdict
          };
        }
        if (!auditResponse?.ok || !auditResponse.verdict) {
          throw new Error(auditResponse?.error || "Extension audit failed.");
        }
        const verdict = auditResponse.verdict;
        const isConnectOnly = payload.walletMethod === "connect" || payload.walletMethod === "eth_requestAccounts" || payload.walletMethod === "wallet_requestPermissions";
        if (isConnectOnly && verdict.decision === "SAFE" && !verdict.timeoutUnverified) {
          return {
            requestId: payload.requestId,
            allow: true,
            userAction: "APPROVED",
            verdict
          };
        }
        const allow = await enqueueOverlay(
          () => showSolShieldOverlay(payload, verdict)
        );
        const userAction = allow ? "APPROVED" : "REJECTED";
        const historyEntry = {
          id: payload.requestId,
          timestamp: Date.now(),
          hostname: verdict.domainEvaluation.hostname,
          walletMethod: payload.walletMethod,
          decision: verdict.decision,
          riskScore: verdict.riskScore,
          headline: verdict.headline,
          apiVerified: verdict.apiVerified,
          timeoutUnverified: verdict.timeoutUnverified,
          userAction,
          txCount: verdict.txCount
        };
        void chrome.runtime.sendMessage({ type: "SOLSHIELD_RECORD_HISTORY", entry: historyEntry }).catch(() => {
        });
        return {
          requestId: payload.requestId,
          allow,
          userAction,
          verdict,
          errorMessage: allow ? void 0 : `SolShield Guard blocked/rejected transaction (${verdict.decision}).`
        };
      } catch (err) {
        const msg = err instanceof Error ? err.message : "SolShield Guard internal error";
        return {
          requestId: payload.requestId,
          allow: false,
          userAction: "REJECTED",
          verdict: {
            decision: "BLOCK",
            riskScore: 85,
            headline: "SOLSHIELD GUARD COMMUNICATION ERROR",
            requiresTypedConfirmation: true,
            apiVerified: false,
            timeoutUnverified: true,
            walletMethod: payload.walletMethod,
            txCount: payload.base64Transactions?.length ?? 0,
            domainEvaluation: {
              hostname: payload.hostname,
              status: "UNVERIFIED",
              riskScore: 40,
              riskLevel: "MEDIUM",
              isAllowlisted: false,
              isPunycode: false,
              closestVerifiedBrand: null,
              matchedVerifiedDomain: null,
              reasons: [msg]
            },
            localReports: [],
            balanceDiffs: [],
            tokenAudits: [],
            reasons: [msg],
            veniceSummary: null,
            privacyAttestation: "Local safety fallback triggered."
          },
          errorMessage: msg
        };
      }
    }
    function escapeHtml(raw) {
      return raw.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }
    function showSolShieldOverlay(payload, verdict) {
      return new Promise((resolve) => {
        const existing = document.getElementById("solshield-guard-overlay-root");
        if (existing) existing.remove();
        const host = document.createElement("div");
        host.id = "solshield-guard-overlay-root";
        host.style.cssText = "all: initial; position: fixed; inset: 0; z-index: 2147483647;";
        const shadow = host.attachShadow({ mode: "closed" });
        const badgeColor = verdict.decision === "BLOCK" ? "#EF4444" : verdict.decision === "WARNING" ? "#F59E0B" : "#10B981";
        const badgeBg = verdict.decision === "BLOCK" ? "rgba(239, 68, 68, 0.14)" : verdict.decision === "WARNING" ? "rgba(245, 158, 11, 0.14)" : "rgba(16, 185, 129, 0.14)";
        const domainBadgeLabel = verdict.domainEvaluation.status === "VERIFIED" ? `VERIFIED \xB7 ${verdict.domainEvaluation.closestVerifiedBrand ?? "Trusted"}` : verdict.domainEvaluation.status === "DEV_LOCAL" ? "DEV LOCALHOST" : verdict.domainEvaluation.status;
        const diffsHtml = verdict.balanceDiffs.length > 0 ? verdict.balanceDiffs.map((diff) => {
          const isIn = diff.direction === "IN";
          const sign = isIn ? "+" : "-";
          const color = isIn ? "#34D399" : "#F87171";
          const tag = diff.isToken2022 ? " [Token-2022]" : "";
          return `<div class="diff-row">
                  <span class="diff-asset">${escapeHtml(diff.asset + tag)}</span>
                  <span class="diff-amt" style="color:${color}">${sign}${Math.abs(
            diff.deltaUiAmount
          ).toFixed(4)}</span>
                </div>`;
        }).join("") : `<div class="muted-note">No measurable balance change decoded locally/on-chain.</div>`;
        const tokenAuditHtml = verdict.tokenAudits.length > 0 ? `<div class="section">
              <div class="section-title">Token Mint Security</div>
              ${verdict.tokenAudits.map(
          (t) => `<div class="token-row">
                      <span>${escapeHtml(t.symbol || t.mintAddress.slice(0, 8))}</span>
                      <span class="pill pill-${escapeHtml(
            t.classification.toLowerCase()
          )}">${escapeHtml(t.classification)} \xB7 ${t.riskScore}/100</span>
                    </div>`
        ).join("")}
            </div>` : "";
        const reasonsHtml = verdict.reasons.slice(0, 6).map((r) => `<li>${escapeHtml(r)}</li>`).join("");
        const veniceBlock = verdict.veniceSummary ? `<div class="section venice-box">
            <div class="section-title">Venice AI Intelligence Summary</div>
            <p class="venice-text">${escapeHtml(vericeSafe(verdict.veniceSummary))}</p>
          </div>` : "";
        const unverifiedBanner = verdict.timeoutUnverified ? `<div class="unverified-banner">
            Belum terverifikasi server SolShield \u2014 keputusan memakai inspeksi lokal & Domain Guard saja.
          </div>` : "";
        const evmSummaryHtml = verdict.evmReport ? `<div class="section">
            <div class="section-title">Decoded EVM Payload (${escapeHtml(
          verdict.evmReport.chainIdHex || "EVM"
        )})</div>
            <div class="diff-row">
              <span>Action</span>
              <span style="font-family: ui-monospace, monospace; color:#93C5FD;">${escapeHtml(
          verdict.evmReport.summary.slice(0, 56)
        )}</span>
            </div>
            ${verdict.evmReport.spenderDetected ? `<div class="diff-row">
                    <span>Spender</span>
                    <span style="font-family: ui-monospace, monospace; color:#FCA5A5;">${escapeHtml(
          verdict.evmReport.spenderDetected
        )}</span>
                  </div>` : ""}
          </div>` : "";
        const allowInputHtml = verdict.requiresTypedConfirmation ? `<div class="allow-gate">
            <label for="solsh-allow-input">Transaksi diblokir karena risiko CRITICAL/HIGH. Ketik <strong>ALLOW</strong> untuk membuka tombol lanjut:</label>
            <input id="solsh-allow-input" type="text" autocomplete="off" spellcheck="false" placeholder="Ketik ALLOW" />
          </div>` : "";
        shadow.innerHTML = `
        <style>
          * { box-sizing: border-box; font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
          .backdrop {
            position: fixed; inset: 0;
            background: rgba(4, 7, 15, 0.78);
            backdrop-filter: blur(8px);
            display: flex; align-items: center; justify-content: center;
            padding: 16px;
          }
          .modal {
            width: 100%; max-width: 470px; max-height: 92vh; overflow-y: auto;
            background: #0B101B;
            color: #F1F5F9;
            border: 1px solid rgba(41, 52, 255, 0.45);
            border-radius: 16px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.75), 0 0 0 1px rgba(255,255,255,0.04);
            padding: 16px 18px;
          }
          .header { display: flex; justify-content: space-between; align-items: center; gap: 10px; margin-bottom: 10px; }
          .brand { display: flex; align-items: center; gap: 9px; font-weight: 700; font-size: 13.5px; letter-spacing: 0.05em; color: #E2E8F0; }
          .brand-logo { width: 24px; height: 24px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.22); object-fit: cover; background: #09090B; flex-shrink: 0; }
          .meta-tag { font-size: 11px; font-family: ui-monospace, monospace; background: #141C2E; border: 1px solid #26314A; color: #94A3B8; padding: 4px 8px; border-radius: 999px; }
          .verdict-card {
            background: ${badgeBg};
            border: 1px solid ${badgeColor};
            border-radius: 12px; padding: 11px 12px; margin-bottom: 10px;
          }
          .verdict-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
          .verdict-pill { font-size: 12px; font-weight: 800; letter-spacing: 0.06em; color: ${badgeColor}; }
          .risk-score { font-family: ui-monospace, monospace; font-size: 13px; font-weight: 700; color: ${badgeColor}; }
          .headline { font-size: 13px; font-weight: 600; color: #F8FAFC; line-height: 1.4; }
          .domain-bar {
            display: flex; justify-content: space-between; align-items: center;
            background: #101727; border: 1px solid #1E293B; border-radius: 10px;
            padding: 7px 11px; margin-bottom: 9px; font-size: 12px;
          }
          .domain-host { font-family: ui-monospace, monospace; color: #CBD5E1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 240px; }
          .domain-pill { font-size: 11px; font-weight: 700; color: #93C5FD; }
          .unverified-banner {
            background: rgba(245, 158, 11, 0.14); border: 1px solid #F59E0B;
            color: #FCD34D; border-radius: 10px; padding: 8px 11px;
            font-size: 12px; line-height: 1.4; margin-bottom: 9px;
          }
          .section { background: #101727; border: 1px solid #1E293B; border-radius: 10px; padding: 9px 11px; margin-bottom: 8px; }
          .section-title { font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; color: #64748B; font-weight: 700; margin-bottom: 5px; }
          .diff-row, .token-row { display: flex; justify-content: space-between; align-items: center; font-size: 13px; padding: 4px 0; border-bottom: 1px dashed rgba(148,163,184,0.14); }
          .diff-row:last-child, .token-row:last-child { border-bottom: none; }
          .diff-amt { font-family: ui-monospace, monospace; font-weight: 700; }
          .muted-note { font-size: 12px; color: #94A3B8; }
          ul.reasons { margin: 0; padding-left: 16px; font-size: 12px; color: #CBD5E1; line-height: 1.5; }
          ul.reasons li { margin-bottom: 4px; }
          .venice-box { border-color: rgba(41, 52, 255, 0.4); }
          .venice-text { margin: 0; font-size: 12px; color: #CBD5E1; line-height: 1.45; }
          .pill { font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 999px; background: #1E293B; color: #E2E8F0; }
          .pill-critical { background: rgba(239,68,68,0.2); color: #FCA5A5; }
          .pill-caution { background: rgba(245,158,11,0.2); color: #FCD34D; }
          .pill-safe { background: rgba(16,185,129,0.2); color: #6EE7B7; }
          .allow-gate {
            background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.5);
            border-radius: 10px; padding: 10px 12px; margin-bottom: 12px;
          }
          .allow-gate label { display: block; font-size: 12px; color: #FECACA; margin-bottom: 7px; line-height: 1.4; }
          .allow-gate input {
            width: 100%; background: #070B14; border: 1px solid #EF4444;
            color: #F8FAFC; border-radius: 8px; padding: 8px 10px; font-size: 13px;
            font-family: ui-monospace, monospace; outline: none;
          }
          .actions { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 14px; }
          button {
            border-radius: 10px; padding: 11px 14px; font-size: 13px; font-weight: 700;
            cursor: pointer; border: 1px solid transparent; transition: opacity 0.15s;
          }
          #solsh-reject {
            background: #2934FF; color: #FFFFFF;
          }
          #solsh-reject:hover { opacity: 0.92; }
          #solsh-approve {
            background: #172033; color: #E2E8F0; border-color: #334155;
          }
          #solsh-approve.safe-btn {
            background: #10B981; color: #04130D;
          }
          #solsh-approve:disabled {
            opacity: 0.38; cursor: not-allowed;
          }
          .privacy-foot {
            margin-top: 10px; font-size: 10px; color: #64748B; text-align: center; line-height: 1.4;
          }
        </style>
        <div class="backdrop">
          <div class="modal" role="dialog" aria-modal="true">
            <div class="header">
              <div class="brand">
                <img class="brand-logo" src="${icon48_default}" alt="SolShield" />
                <span>SOLSHIELD BROWSER GUARD</span>
              </div>
              <span class="meta-tag">${escapeHtml(payload.walletName)} \xB7 ${escapeHtml(
          payload.walletMethod
        )}</span>
            </div>

            <div class="verdict-card">
              <div class="verdict-top">
                <span class="verdict-pill">${escapeHtml(verdict.decision)}</span>
                <span class="risk-score">Risk ${verdict.riskScore}/99</span>
              </div>
              <div class="headline">${escapeHtml(verdict.headline)}</div>
            </div>

            <div class="domain-bar">
              <span class="domain-host">${escapeHtml(
          verdict.domainEvaluation.hostname
        )}</span>
              <span class="domain-pill">${escapeHtml(domainBadgeLabel)}</span>
            </div>

            ${unverifiedBanner}

            <div class="section">
              <div class="section-title">Simulated Balance Impact (${verdict.txCount} tx)</div>
              ${diffsHtml}
            </div>

            ${tokenAuditHtml}
            ${evmSummaryHtml}

            <div class="section">
              <div class="section-title">Security Findings</div>
              <ul class="reasons">
                ${reasonsHtml || "<li>Deterministic instruction scan passed with no critical flags.</li>"}
              </ul>
            </div>

            ${veniceBlock}
            ${allowInputHtml}

            <div class="actions">
              <button id="solsh-reject" type="button">Reject Transaction</button>
              <button id="solsh-approve" type="button" class="${verdict.decision === "SAFE" ? "safe-btn" : ""}" ${verdict.requiresTypedConfirmation ? "disabled" : ""}>
                ${verdict.decision === "BLOCK" ? "Proceed Anyway" : "Approve & Sign"}
              </button>
            </div>
            <div class="privacy-foot">${escapeHtml(
          verdict.privacyAttestation
        )}</div>
          </div>
        </div>
      `;
        const rejectBtn = shadow.getElementById("solsh-reject");
        const approveBtn = shadow.getElementById(
          "solsh-approve"
        );
        const allowInput = shadow.getElementById(
          "solsh-allow-input"
        );
        function cleanup(result) {
          window.removeEventListener("keydown", onKeyDown, true);
          host.remove();
          resolve(result);
        }
        function onKeyDown(ev) {
          if (ev.key === "Escape") {
            ev.preventDefault();
            cleanup(false);
          }
        }
        if (allowInput) {
          allowInput.addEventListener("input", () => {
            approveBtn.disabled = allowInput.value.trim() !== "ALLOW";
          });
        }
        rejectBtn.addEventListener("click", () => cleanup(false));
        approveBtn.addEventListener("click", () => {
          if (verdict.requiresTypedConfirmation) {
            if (!allowInput || allowInput.value.trim() !== "ALLOW") return;
          }
          cleanup(true);
        });
        window.addEventListener("keydown", onKeyDown, true);
        (document.body || document.documentElement).appendChild(host);
        rejectBtn.focus({ preventScroll: true });
      });
    }
    function vericeSafe(input) {
      return input.slice(0, 420);
    }
  })();
})();
